public class OutOfRangeWeightException extends Exception
                                                                               implements IBMI {
    public OutOfRangeWeightException(){
        super("Weight Must Be Between " + MINWEIGHT + " and " + MAXWEIGHT);
    }
}
