public class OutOfRangeHeightException extends Exception
                                                                             implements IBMI {
    public OutOfRangeHeightException(){
        super("Height Must Be Between " + MINHEIGHT + " and " + MAXHEIGHT);
    }
}
