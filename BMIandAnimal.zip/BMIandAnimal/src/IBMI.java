public interface IBMI {
    //  Constants
    static double MINHEIGHT = 12.0;
    static double MAXHEIGHT = 96.0;
    static double DEFHEIGHT = 96.0;

    static double MINWEIGHT = 1.0;
    static double MAXWEIGHT = 777.0;
    static double DEFWEIGHT = 777.0;

    static double UNDERWEIGHTBMI = 18.5;

    static double MINOPTIMALWEIGHTBMI = 18.6;
    static double MAXOPTIMALWEIGHTBMI = 25.0;

    static double MINOVERWEIGHTBMI = 25.1;
    static double MAXOVERWEIGHTBMI = 30.0;

    static double OBESEBMI = 30.1;

    static String UNDERWEIGHT = "Underweight";
    static String OPTIMALWEIGHT = "Optimal Weight";
    static String OVERWEIGHT = " Overweight";
    static String OBESE = "Obese";

}
