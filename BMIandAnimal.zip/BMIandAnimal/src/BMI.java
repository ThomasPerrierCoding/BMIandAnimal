public abstract class BMI
                    implements IBMI {

}
